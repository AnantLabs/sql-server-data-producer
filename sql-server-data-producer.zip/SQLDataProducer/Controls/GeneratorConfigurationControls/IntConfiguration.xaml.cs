﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SQLRepeater.Controls.GeneratorConfigurationControls
{
    /// <summary>
    /// Interaction logic for IntConfiguration.xaml
    /// </summary>
    public partial class IntConfiguration : UserControl
    {

        //private Entities.ValueGeneratorParameters.IntParameter _intParamter;

        //public IntConfiguration(Entities.ValueGeneratorParameters.IntParameter intParameter)
        //{
        //    this.DataContext = null;
        //    _intParamter = intParameter;
        //    Loaded += new RoutedEventHandler(IntConfiguration_Loaded);
        //    InitializeComponent();
        //}

        //void IntConfiguration_Loaded(object sender, RoutedEventArgs e)
        //{
        //    this.DataContext = _intParamter;
        //}
    }
}
