﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SQLDataProducer.ViewModels
{
    public interface IYesNoViewModel
    {
        void OnYes();
        void OnNo();
    }
}
